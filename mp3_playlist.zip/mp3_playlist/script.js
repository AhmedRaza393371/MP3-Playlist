let ctrlIcon = document.querySelector("#ctrlIcon");
let song = document.querySelector("#song");
let progress = document.querySelector("#progress");
let songs = ["song.mp3", "song1.mp3", "song2.mp3", "song3.mp3"];
let currentSongIndex = 0;

// Load the current song
function loadSong(index) {
    song.src = songs[index];
    song.load();
    progress.value = 0;
    ctrlIcon.classList.remove("fa-pause");
    ctrlIcon.classList.add("fa-play");
}

// Play/Pause function
function playPause() {
    if (song.paused) {
        song.play();
        ctrlIcon.classList.remove("fa-play");
        ctrlIcon.classList.add("fa-pause");
    } else {
        song.pause();
        ctrlIcon.classList.remove("fa-pause");
        ctrlIcon.classList.add("fa-play");
    }
}

// Update progress bar as song plays
song.ontimeupdate = function() {
    progress.value = song.currentTime;
};

// Set max value of progress bar to song duration
song.onloadedmetadata = function() {
    progress.max = song.duration;
};

// Update song current time based on progress bar change
progress.oninput = function() {
    song.currentTime = progress.value;
};

// Play the next song when the current song ends
song.onended = function() {
    nextSong();
};

// Function to play the next song
function nextSong() {
    if (currentSongIndex < songs.length - 1) {
        currentSongIndex++;
        loadSong(currentSongIndex);
        song.play();
        ctrlIcon.classList.remove("fa-play");
        ctrlIcon.classList.add("fa-pause");
    } else {
        song.pause();
        ctrlIcon.classList.remove("fa-pause");
        ctrlIcon.classList.add("fa-play");
    }
}

// Function to play the previous song
function previousSong() {
    if (currentSongIndex > 0) {
        currentSongIndex--;
        loadSong(currentSongIndex);
        song.play();
        ctrlIcon.classList.remove("fa-play");
        ctrlIcon.classList.add("fa-pause");
    }
}

// Load the first song initially
loadSong(currentSongIndex);

// Add event listener to the play/pause control
ctrlIcon.addEventListener("click", playPause);

// Add event listener to the next button
document.querySelector(".fa-forward").addEventListener("click", nextSong);

// Add event listener to the previous button
document.querySelector(".fa-backward").addEventListener("click", previousSong);
